

flush-mem
=========
- I've included this because I use it a lot during testing. Just run it as admin and it will clear memory.
- If you use ISLC and it's set up incorrectly it will flush memory too often and during game play, which will likely cause stalls ingame (check # times run in ISLC)
- ISLC also does not seem to flush as much as flush-mem



License
=======
I was unable to contact the author of EmptyStandbyList.exe nor find a license, and the download was broken, so I've included it here. To the author, please don't hesitate to contact me if this is not okay (or for any reason).