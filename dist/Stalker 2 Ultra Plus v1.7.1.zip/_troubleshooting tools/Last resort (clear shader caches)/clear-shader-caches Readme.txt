

clear-shader-caches
===================
I've included this because I use it during testing.

Clearing shader caches is part of the Troubleshooting Guide (on the Ultra+ mod Description page)

Clearing may help if:

- Your save game won't load
- You're having in-game stutters even though you're using Ultra+
- Or textures aren't loading properly


NOTE: Close all 3D software before running this script (including Steam, Epic or GOG Launcher,
MSI Afterburner, etc.)
